/* (A)
SELECT s.sid, s.sname, r.cid FROM student s
INNER JOIN registration r ON s.sid = r.sid
WHERE r.semester='I-2001';
#B
select s.sid, sname, cid
from student s, registration r
where s.sid = r.sid and semester = 'I-2001'; */
#C
#SELECT f.fid, f.fname FROM Faculty f, qualification q
#where f.fid = q.fid and extract(year from date_qualified) = 1995;
#D
#SELECT c.cname, c.cid FROM course c, qualification q, faculty f
#WHERE c.cid = q.cid and q.fid = f.fid and f.fname = 'Ama' order by cid desc;
#E
#SELECT distinct f.fid, f.fname FROM FACULTY f, qualification q 
#where f.fid = q.fid order by fname asc;
#F
#SELECT r.sid FROM registration r, course c
#WHERE r.cid = c.cid and r.semester ='I-2001' and cname='Syst Analysis';
#G
#select s.sid, s.sname from student s, registration r, course c
#where s.sid = r.sid and r.cid = c.cid and cname ='Syst Analysis' and semester = 'I-2001';
#H
#select c.cname, c.cid, s.sname from course c, student s, registration r
#where c.cid = r.cid and r.sid = s.sid 
#and s.sname like 'a%';
#I
#select distinct s.sid, s.sname from student s, registration r, qualification q, faculty f
#where s.sid = r.sid and r.cid = q.cid and q.fid = f.fid and f.fname = 'berry';
#J
#select f.fid, f.fname, q.cid from faculty f left outer join qualification q on f.fid = q.fid ;

#select f.fid, f.fname, c.cname from faculty f
#left outer join qualification q on f.fid = q.fid left outer join course c on q.cid = c.cid;

#select f.fid, f.fname, count(distinct q.cid) as NoOfCourses 
#from faculty f left outer join qualification q on f.fid = q.fid group by f.fid, fname;

#select s.sid, s.sname, count(distinct r.cid) as NoOfCourses
#from student s left outer join registration r on s.sid = r.sid and semester = 'I-2002'
#group by s.sid, s.sname;

#select c.cid, c.cname, count(r.sid) as NoOfStudents
#from course c left outer join registration r on c.cid = r.cid and semester = 'I-2002'
#group by c.cid, c.cname;

#select s.sid, f.fid, sname as Name from student s, faculty f where sname = fname;

#select s.sid, f.fid, sname as Name from student s, faculty f where sname <> fname;

#select p.cid, p.sid, sum(p.mark * a.weight) as FINALMARK
#from performance p, assessment a where p.aid = a.aid group by p.cid, p.sid;

#select s.sid from student s, registration r, course c
#where s.sid = r.sid and r.cid = c.cid and c.cname in ('Database','Networking')
#group by s.sid having count(distinct c.cid) = 2;

select fid from course c, qualification q where c.cid = q.cid
and cname in ('Syst Analysis', 'Syst Design')
group by fid having count(distinct cname) = 1

#select q1.fid, q2.fid, cname from qualification q1 inner join qualification q2 
#on q1.cid = q2.cid and q1.fid < q2.fid inner join course c on q1.cid = c.cid;

#select r1.rid, r2.rid, r1.type, r1.capacity from room r1 inner join room r2
#on r1.rid < r2.rid and r1.capacity = r2.capacity and r1.type = r2.type;

#select s1.sname, s2.sname, cname, r1.semester from student s1 inner join registration r1 on s1.sid = r1.sid
#inner join registration r2 on r1.cid = r2.cid and r1.semester = r2.semester 
#inner join student s2 on r2.sid = s2.sid and s1.sid < s2.sid
#inner join course c on r1.cid = c.cid