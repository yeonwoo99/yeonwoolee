#q1
select i.item_id, i.title as 'Item Title' , sum(lc.num_of_copies) as 'Total Number of copies in all libraries', 
 (select count(Item_ID) from transaction_item ti inner join transaction t on ti.Card_ID = t.Card_ID and t.Tr_DateTime = ti.Tr_DateTime
where (Transaction_Type = 'lend' or Transaction_Type = 'renew') and Item_ID = i.item_id) as 'Total number of transactions (lend + renew)', 
 (select count(*) from visit_items vi where vi.item_id=i.item_id) as 'Number of times item was brought during visits'  
 from item i,library_copies lc
 where i.item_id=lc.item_id and i.Item_Type = 'Book' and i.Publish_Year = 2000
 group by i.item_id;
 
#q2
SELECT  query1.Series_Title as 'Series Title', query1.Series_Order as 'Series Order', 
		query1.Title, query1.Item_ID as 'Item ID', query1.Call_Number as 'Call Number',
case when query2.available_in_video is not null
then 'Yes'
else 'No'
end as 'Item Title Available in Video?', 
case when query3.available_in_audio is not null
then 'Yes'
else 'No'
end as 'Item Title Available in Audio?'
FROM
(
select Series_Title, Series_Order, Title, Item_ID, Call_Number
from item
where item_type = 'book' and 
series_title is not null
) query1
	LEFT OUTER JOIN
	(
		select Series_Title, Series_Order, Title, Item_ID, Call_Number,
		"Yes" available_in_video
		from item
		where item_type='Video'
	) as query2 ON query1.title=query2.title 
	LEFT OUTER JOIN
	(
		select Series_Title, Series_Order, Title, Item_ID, Call_Number,
		"Yes" available_in_audio
		from item
		where item_type='Audio'
	) as query3 ON query1.title=query3.title
order by query1.series_title, query1.Series_order ASC

#q3
select i.Item_ID as 'Item ID',i.Title as 'Item title',IFNULL(lending.lendCount,0) as 'n1', IFNULL(renewing.renewCount,0) as 'n2',IFNULL(lending.lendCount,0)+IFNULL(renewing.renewCount,0) as 'Sum of Popularity Value (n1+n2)' from 
(SELECT ti.Item_ID as 'Id', count(ti.Item_ID) as 'lendCount'
from transaction t, transaction_item ti 
where t.card_id=ti.card_ID 
 and t.Transaction_Type='Lend' 
    and t.Tr_DateTime=ti.Tr_DateTime
 and (CAST(ti.tr_dateTime as DATE) between '2017-01-01' and '2017-03-31')
GROUP BY ti.Item_ID) as lending left outer join
(SELECT ti.Item_ID as 'Id',count(ti.Item_ID) as 'renewCount'
from transaction t, transaction_item ti 
where t.card_id=ti.card_ID 
 and t.Transaction_Type='Renew' 
    and t.Tr_DateTime=ti.Tr_DateTime
 and (CAST(ti.tr_dateTime as DATE) between '2017-01-01' and '2017-03-31')
GROUP BY ti.Item_ID) as renewing
on lending.Id=renewing.Id
inner join item i on i.item_id=lending.Id
order by (IFNULL(lending.lendCount,0)+IFNULL(renewing.renewCount,0)) desc
limit 3;

#q4
delimiter $$
CREATE TRIGGER before_transaction_item_insert
 BEFORE INSERT ON transaction_item 
 FOR EACH ROW
BEGIN
#member type max limit
 DECLARE maxLimit int;
 DECLARE borrowed int;
 DECLARE returned int;
    
SET maxLimit=(SELECT mt.borrow_limit from membership_type mt, card c
  where c.Card_ID=new.Card_ID and c.member_type=mt.name);

#how many borrowed
    SET borrowed=(select count(*) from transaction 
where Card_ID=new.Card_ID and transaction_type='Lend');
#how many returned
    SET returned=(select count(*) from transaction 
where Card_ID=new.Card_ID and transaction_type='Return');

 IF ((borrowed-returned)>=maxLimit) THEN
  signal sqlstate '45000'
  set message_text='Member has reached the borrowing limit';
    END IF;
END$$
delimiter ;

#q5
delimiter $$
CREATE PROCEDURE sp_reminder(IN maxDate DATE)
  BEGIN
		#declaration
        DECLARE maxBorrowDateNP DATE;
		DECLARE minBorrowDateNP DATE;
        DECLARE maxBorrowDateP DATE;
		DECLARE minBorrowDateP DATE;
        DECLARE maxRenewDate DATE;
		DECLARE minRenewDate DATE;
        
        DECLARE nonPremiumLoanPeriod int;
        DECLARE premiumLoanPeriod int;
        DECLARE renewLoanPeriod int;
        
        #window for transaction dates
        #21 days: for book/score, and all member types except pp
        #n+1
        #NOT INCLUSIVE
        SET nonPremiumLoanPeriod=(select distinct(loan_period) from membership_type where name!='PremiumPlus');
        SET premiumLoanPeriod=(select distinct(loan_period) from membership_type where name='PremiumPlus');
        SET renewLoanPeriod=(select distinct(it.loan_renewal_period) from item_type it,item i 
            where (i.item_type='Book' or i.item_type='Music Scores') and i.item_type=it.name);
        
        SET minBorrowDateNP=(select DATE_ADD(maxDate, INTERVAL (1-nonPremiumLoanPeriod) DAY));
        set maxBorrowDateNP=(select DATE_ADD(maxDate, INTERVAL (5-nonPremiumLoanPeriod) DAY));
            
        SET minBorrowDateP=(select DATE_ADD(maxDate, INTERVAL (1-premiumLoanPeriod) DAY));
        set maxBorrowDateP=(select DATE_ADD(maxDate, INTERVAL (5-premiumLoanPeriod) DAY));
        
        SET minRenewDate=(select DATE_ADD(maxDate, INTERVAL (1-renewLoanPeriod) DAY));
        set maxRenewDate=(select DATE_ADD(maxDate, INTERVAL (5-renewLoanPeriod) DAY));
        #lend, not premium      
        #and ti.tr_datetime>=minBorrowDate and ti.tr_datetime<=maxBorrowDate
        #order by ti.tr_datetime;
        
        #lend, premium
        #order by ti.tr_datetime;
        
        /*select * from(       
 
			#subquery 1: non-premium lends
			(*/
            select c.card_id,c.name,i.item_id,i.title,i.item_type,
            t.lib_name,ti.tr_datetime,t.transaction_type, 
            
            #21 days ONLY    
            CASE
				WHEN (t.transaction_type='Lend' and c.member_type!='PremiumPlus')
                THEN (select timestampdiff(day,maxDate,DATE_ADD(DATE_ADD(ti.tr_datetime, INTERVAL -1 DAY), INTERVAL nonPremiumLoanPeriod DAY)))
				
				WHEN (t.transaction_type='Lend' and c.member_type='PremiumPlus')
                THEN (select timestampdiff(day,maxDate,DATE_ADD(DATE_ADD(ti.tr_datetime, INTERVAL -1 DAY), INTERVAL PremiumLoanPeriod DAY)))
				
				WHEN (t.transaction_type='Renew' and (i.item_type='Book' or i.item_type='Music Scores'))
                THEN (select timestampdiff(day,maxDate,DATE_ADD(DATE_ADD(ti.tr_datetime, INTERVAL -1 DAY), INTERVAL renewLoanPeriod DAY)))
			
            END as diff
			
            from transaction_item ti, transaction t, card c, item i
			where ti.card_id=t.card_id and ti.tr_datetime=t.tr_datetime
			and ti.card_id=c.card_id and i.item_id=ti.item_id
            and(
				(c.member_type!='PremiumPlus'
				and t.transaction_type='Lend'
				and ti.tr_datetime between minBorrowDateNP and maxBorrowDateNP) 
				or 
				(c.member_type ='PremiumPlus'
				and t.transaction_type='Lend'
				and ti.tr_datetime between minBorrowDateP and maxBorrowDateP)
				or
				(t.transaction_type='Renew' and (i.item_type='Book' or i.item_type='Music Scores')
				and ti.tr_datetime between minRenewDate and maxRenewDate)
            )
            order by ti.tr_datetime;
			/*
			UNION
			
			#subquery 2: premium lends
			(select c.card_id,c.name,i.item_id,i.title,i.item_type,t.lib_name,ti.tr_datetime,t.transaction_type 
			from transaction_item ti, transaction t, card c, item i
			where )
            
        ) as t
        order by t.tr_datetime;*/
        /*
        #lend, premium
        select * from transaction_item ti, transaction t, card c, item i
        where ti.card_id=t.card_id and ti.tr_datetime=t.tr_datetime
		and ti.card_id=c.card_id
        and t.transaction_type='Renew'
        and i.item_id=ti.item_id and (i.item_type='Book' or i.item_type='Music Scores')
        and ti.tr_datetime between '2017-01-01' and '2017-02-01';*/
        #book/score renew: 21
        #member loan: 21 EXCEPT premiumplus(28)
        
	 END$$
delimiter ;

#q6
SET @@session.max_sp_recursion_depth = 255;

#to get newest card
DELIMITER $$
CREATE PROCEDURE getNewestCard(
   IN cardId CHAR(8),
   OUT newestCard CHAR(8)
)

BEGIN
	if (cardId not in (select old_id from card where old_id is not null))
	then
		set newestCard=cardId;
    else
		call getNewestCard((select card_id from card where old_id=cardId),newestCard);
    end if;
END$$
DELIMITER ;

DELIMITER $$
CREATE FUNCTION getNewestCardGivenId(
	inCard CHAR(8)) RETURNS CHAR(8)
	begin
	call getNewestCard(inCard,@nCard);
	return @nCard;
    END$$    
DELIMITER ;

#to get num replacements
DELIMITER $$
CREATE PROCEDURE countNumReplacements(
   IN cardId CHAR(8),
   IN curCount INT,
   OUT finalC INT
)

BEGIN
 DECLARE currentReplacementCount INT;
 DECLARE oldId CHAR(8);
    
    SET currentReplacementCount=curCount;
    select old_id into oldId from card where card_id=cardId;
    if oldId is null then
  SET finalC=currentReplacementCount;
 else
        SET currentReplacementCount=currentReplacementCount+1;
  call countNumReplacements(oldId,currentReplacementCount,finalC);
    end if;
END$$
DELIMITER ;
    
DELIMITER $$
CREATE FUNCTION getNumReplacementsGivenID(
   inCard CHAR(8)
)returns INT
BEGIN
call countNumReplacements(inCard,0,@finalCount);
return @finalCount;
END$$
DELIMITER ;

SELECT distinct member_type as 'Membership Type' , name as 'Member Name',
       getNewestCardGivenId(card_id) as 'CardID (Latest)',
       getNumReplacementsGivenId(getNewestCardGivenId(card_id)) as 'Total Number of Replacements'
FROM card 
WHERE member_type='Basic' order by name;