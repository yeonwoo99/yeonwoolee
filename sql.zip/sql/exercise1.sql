#INSERT INTO STUDENT(sid, sname) VALUES (65798, 'Lopez');
#DELETE FROM STUDENT WHERE sid=65798;
#UPDATE FACULTY SET fname='Collin' WHERE fid=4756;\
#SELECT aname from assessment where weight>0.3;
#SELECT sid, sname from student where sid<5000;
#SELECT fname FROM FACULTY where fid=4756;
#SELECT * FROM QUALIFICATION WHERE extract(year from date_qualified) >= 1993;
#SELECT fname FROM FACULTY WHERE fname like '%a%';
#SELECT cid, cname from COURSE WHERE cid like '%ism%';
#SELECT min(mark) FROM PERFORMANCE where aid=1 and cid='ISM 3112';
#SELECT count(*) FROM registration WHERE cid='ISM 4212' and semester='I-2001';
#SELECT count(distinct sid) as TotalNumber FROM registration where semester='I-2001';
#SELECT fid FROM QUALIFICATION WHERE (cid='ISM 3112' or cid='ISM 3113') and extract(month from date_qualified)=9;
#SELECT distinct(cid) as TotalNumber FROM registration where semester='I-2001';
#SELECT sid, sname FROM STUDENT order by sname ASC;
#select sid, max(mark) as 'Best Performance' from performance group by sid;
#SELECT type, count(*) from ROOM group by type;
#SELECT cid, count(*) as NoFaculty FROM qualification group by cid;
#SELECT sid, count(*) as NoCourses FROM registration group by sid;
/*SELECT aid, min(mark) as MinMark, max(mark) as MaxMark, avg(mark) as AvgMark FROM performance 
where cid='ISM 4212' group by aid;*/
#select cid, aid, min(mark), max(mark), avg(mark) from performance group by cid, aid;
/*SELECT cid, aid, min(mark) as MinMark, max(mark) as MaxMark, avg(mark) as AvgMark FROM performance 
where cid !='ISM 4212' group by cid, aid;*/
#SELECT cid, count(*) as NoFaculty FROM qualification group by cid having NoFaculty>=2;


