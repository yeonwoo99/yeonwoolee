#Select eid from certified where aid = 1;
#select fly_to as destination from flight order by fly_to desc
#select eid from employee where salary between 70000 and 100000;
#select max(cruisingrange) from aircraft;
#select e.ename, e.salary, a.aname from employee e
#left outer join certified c on e.eid = c.eid
#left outer join aircraft a on c.aid = a.aid;

#alter table employee add speAircraft int;
#alter table employee add constraint FOREIGN KEY(speAircraft) 
#references Aircraft (aid);

#update employee set speAircraft=1 where eid = 1;
#update employee set speAircraft=3 where eid = 2;
#update employee set speAircraft=4 where eid = 3;
#update employee set speAircraft=3 where eid = 4;

#select fly_from, fly_to, min(price) from flight group by fly_from, fly_to;

#select ename, salary from employee where eid not in 
#(select distinct eid from certified) and salary >
#(select avg(salary) from employee where eid in (select c.eid 
#from certified c, aircraft a where a.aid = c.aid and cruisingrange >1000));

#select e.eid, e.ename, min(a.cruisingrange) as min
#from employee e, certified c, aircraft a
#where e.eid = c.eid and c.aid = a.aid
#group by c.eid having count(*) >=2;

#select e.ename, a.aname, c.certdate
#from employee e, certified c, aircraft a
#where e.eid = c.eid and c.aid = a.aid and a.aname like '%b%';

#select e.ename from employee e
#where e.salary < (select min(f.price) from flight f
#where f.fly_from = 'la' and f.fly_to = 'sf');

#select a.aname from aircraft a, certified c, employee e
#where a.aid = c.aid and c.eid = e.eid and e.ename = 'Jacob'
#and a.aid not in (select aid from certified c, employee e
#where c.eid=e.eid and ename<>'Jacob');

/*13
select distinct aname from certified, aircraft where 
certified.aid = aircraft.aid
and certified.aid not in (
select aid from certified where eid not in (
select distinct certified.eid from employee, certified where
certified.eid = employee.eid
and salary between 60000 and 85000)); 

#14
select ename, salary from
certified c, aircraft a, employee e
where c.eid=e.eid and c.aid=a.aid and salary > 70000
group by e.eid
having min(cruisingrange) > (select distance from flight where FLNO = 3);

#15
select ename from employee
where eid in
(select eid from certified c, aircraft a
where c.aid = a.aid
and cruisingrange > 1000)
and eid not in
(select eid from certified c, aircraft a
where c.aid = a.aid
and aname like '%b%');

#16
select certyear, count(*) as cert_no from 
(select eid, aid, year(certdate) as certyear from certified) as temp1
group by certyear
having count(*)  = 
(select max(cert_no) from (
select certyear, count(*) as cert_no from 
(select eid, aid, year(certdate) as certyear from certified) as temp2
group by certyear) as temp3);


#17
select flno, ename from employee e, 
(select eid, max(cruisingrange) as MaxCruisingRange from certified c, aircraft a
where a.aid = c.aid group by eid) as temp, 
(select flno, distance, min(salary) as minsalary 
from employee e, aircraft a, flight f, certified c
where e.eid = c.eid and a.aid = c.aid and a.cruisingrange >= f.distance
group by flno, distance) as temp2
where e.eid = temp.eid and temp.MaxCruisingRange >= temp2.distance
and temp2.minsalary = e.salary;
*/

