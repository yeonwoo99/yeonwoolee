create table book
(ID int not null AUTO_INCREMENT primary key,
 Title varchar(150),
 Abstract text,
 URL varchar(150)); 

insert into book (title, abstract, url) values
('Becoming a data engineer', 'Big data is a dynamic field that finds businesses and organizations capturing massive amounts of information at an alarming speed 
all of which will be analyzed and used to help make important decisions. A data engineer creates the massive reservoirs needed to collect big data. These IT 
professionals develop, construct, test, and maintain architectures, such as databases and large-scale data processing systems, which house big data. In this title, 
the emerging career field of a data engineer is explored. With the right mix of education and experience, data engineers can find themselves in high demand',
'http://catalogue.nlb.gov.sg/cgi-bin/spydus.exe/FULL/EXPNOS/BIBENQ/24619186/222545432,5'),
('The machine in the ghost : digitality and its consequences',	'This book tackles this fundamental question by exploring the origins of the digital and showing how digital technology works. It goes back to 1874, when a French telegraph engineer, Jean-Maurice-E_mile Baudot, invented the first means of digital communication, the Baudot code. From this simple 5-bit code, it takes us to the first electronic computers, to the earliest uses of graphics and information systems in the 1950s, our interactions with computers through punch cards and programming languages, and the rise of digital media in the 1970s. Via various and sometimes unanticipated historical routes, this book reveals the foundations of digitality and how it has flourished in today\'s explosion of technologies and the forms of communication and media they enable, making real the often intangible force that guides so much of our lives.',	'http://catalogue.nlb.gov.sg/cgi-bin/spydus.exe/FULL/EXPNOS/BIBENQ/24619186/219423911,7'),
('Understanding the digital world : what you need to know about computers, the Internet, privacy, and security','Computers are everywhere. Some of them are highly visible, in laptops, tablets, cell phones, and smart watches. But most are invisible, like those in appliances, cars, medical equipment, transportation systems, power grids, and weapons. We never see the myriad computers that quietly collect, share, and sometimes leak vast amounts of personal data about us. Through computers, governments and companies increasingly monitor what we do. Social networks and advertisers know far more about us than we should be comfortable with, using information we freely give them. Criminals have all-too-easy access to our data. Do we truly understand the power of computers in our world? Based on the author\'s Princeton course Computers in Our World, this book is intended as a compact but detailed and thorough explanation of how computers and communications systems work, for non-technical readers. It explains how today\'s computing and communications world operates, from hardware through software to the Internet and the web, also addressing the social, political and legal issues that new technology creates.', 'http://catalogue.nlb.gov.sg/cgi-bin/spydus.exe/FULL/EXPNOS/BIBENQ/24619186/219413920,10'),
('The handbook of high frequency trading', 'This comprehensive examination of high frequency trading looks beyond mathematical models, which are the subject of most HFT books, to the mechanics of the marketplace. In 25 chapters, researchers probe the intricate nature of high frequency market dynamics, market structure, back-office processes, and regulation. They look deeply into computing infrastructure, describing data sources, formats, and required processing rates as well as software architecture and current technologies. They also create contexts, explaining the historical rise of automated trading systems, corresponding technological advances in hardware and software, and the evolution of the trading landscape. Developed for students and professionals who want more than discussions on the econometrics of the modelling process, The Handbook of High Frequency Trading explains the entirety of this controversial trading strategy',	'http://catalogue.nlb.gov.sg/cgi-bin/spydus.exe/FULL/EXPNOS/BIBENQ/24619186/219410801,13'),
('CCSP certified cloud security professional exam guide', 'This highly effective self-study guide covers all six domains of the challenging new Certified Cloud Security Professional exam as well as the CCSP Common Body of Knowledge, developed by the International Information Systems Security Certification Consortium ', 'http://catalogue.nlb.gov.sg/cgi-bin/spydus.exe/FULL/EXPNOS/BIBENQ/24619186/219409191,16'),
('Dashboards for Excel', 'The book takes a hands-on approach to developing dashboards, from instructing users on advanced Excel techniques to addressing dashboard pitfalls common in the real world. Dashboards for Excel is your key to creating informative, actionable, and interactive dashboards and decision support systems. Throughout the book, the reader is challenged to think about Excel and data analytics differently, that is, to think outside the cell. This book shows you how to create dashboards in Excel quickly and effectively.', 'http://catalogue.nlb.gov.sg/cgi-bin/spydus.exe/FULL/EXPNOS/BIBENQ/24619186/216079158,19'),
('Unveiling the North Korean economy : collapse and transition', 'North Korea is one of the most closed and secretive societies in the world. Despite a high level of interest from the outside world, we have very little detailed information about how the country functions economically. In this valuable book for both the academic and policy-making circles, Byung-Yeon Kim offers the most comprehensive and systematic analysis of the present day North Korean economy in the context of economic systems and transition economics. It addresses what is really happening in the North Korean economy, why it has previously failed, and how the country can make the transition to a market economy. It takes advantage not only of carefully reconstructed macro data but also rich, new data at the micro level, such as quantitative surveys of North Korean refugees settled in South Korea, and the surveys of Chinese companies that interact heavily with North Korea','http://catalogue.nlb.gov.sg/cgi-bin/spydus.exe/FULL/EXPNOS/BIBENQ/24619186/216070746,25'),
('Management information systems', 'This global edition has been developed specifically to meet the needs of international management information systems students. In addition to the latest examples of both contemporary and classic business topics, new material has been added to make the content more relevant and improve learning outcomes for the international student.',	'http://catalogue.nlb.gov.sg/cgi-bin/spydus.exe/FULL/EXPNOS/BIBENQ/24619186/216063275,30'),
('We are big data : the future of the information society', 'This book demonstrates the inevitability of a continuously growing role of data in our society and it stresses that this role does not need to be threatening: to the contrary, collection and analysis of data can help us prevent traffic jams, suppress epidemics, or produce tailor made medicine. The authors sketch the contours of a new informationsociety, in which everything will be measured from our heartbeat during our morning run to the music we listen to and our walking patterns through department stores and they discuss the resistances within the society that have to be overcome',	'http://catalogue.nlb.gov.sg/cgi-bin/spydus.exe/FULL/EXPNOS/BIBENQ/24619186/216071851,22'),
('The Information Systems Security Officer\'s Guide: Establishing and Managing a Cyber Security Program', 'This book provides users with information on how to combat the ever-changing myriad of threats security professionals face. This entirely updated edition presents practical advice on establishing, managing, and evaluating a successful information protection program in a corporation or government agency, covering everything from effective communication to career guidance for the information security officer. The book outlines how to implement a new plan or evaluate an existing one, and is especially targeted to those who are new to the topic. It is the definitive resource for learning the key characteristics of an effective information systems security officer (ISSO), and paints a comprehensive portrait of an ISSO\'s duties, their challenges, and working environments, from handling new technologies and threats, to performing information security duties in a national security environment.', 'http://catalogue.nlb.gov.sg/cgi-bin/spydus.exe/FULL/EXPNOS/BIBENQ/24619186/208800690,50'),
('Monitoring with graphite : tracking dynamic host and application metrics at Scale', 'Graphite has become one of the most powerful monitoring tools available today due to its ease of use, rapid graph prototyping abilities, and a friendly rendering API. With this practical guide, system administrators and engineers will learn how to use this open source tool to track operational data you need to monitor your systems, as well as application-level metrics for profiling your services.',	'http://catalogue.nlb.gov.sg/cgi-bin/spydus.exe/FULL/EXPNOS/BIBENQ/24619186/205355394,51'),
('How many cells are in your body? : questions about cells and systems', 'The human body is an amazing machine made up of many fascinating systems. This fun, fact-filled book features a series of questions and answers about how the human body works. Readers will learn what hormones do and how blood travels through the body. Colorful images and clear diagrams make it easy to understand these important biology and health concepts. A further information section provides additional resources for readers who are interested in learning more about how the human body works.',	'http://catalogue.nlb.gov.sg/cgi-bin/spydus.exe/FULL/EXPNOS/BIBENQ/24619186/202141460,60'),
('Curation : the power of selection in a world of excess', 'Curation, or the art of selecting useful information to form meaningful collections, is the new buzzword that tech companies and media professionals have eagerly latched on to. But curation is a far more powerful and deeply relevant idea than we give it credit for. It answers the question of how we live in a world where problems are often about having too much, and shows how we keep growing in a world of excess. Acts of selecting, refining and arranging to add value help us overcome information overload. This book highlights the numerous places in which this simple but forceful skill is increasingly felt: in art and on the Web, but also in retail and manufacturing, high finance and government policy',	'http://catalogue.nlb.gov.sg/cgi-bin/spydus.exe/FULL/EXPNOS/BIBENQ/24619186/202137929,61'),
('Accounting information systems', 'Gain a strong understanding of the accounting information systems and related technologies you will use in your business career with this text. You will find a unique emphasis on ethics, fraud, and the modern manufacturing environment. The book focuses on the needs and responsibilities of accountants as end users of systems, systemsdesigners, and auditors. This text completely integrates Sarbanes-Oxley as it affects internal controls and other relevant topics. In this new edition, you examine the risks and advantages of cloud computing and gain a better understanding of the differences in the manual and automated accounting system needs of small and large companies.',	'http://catalogue.nlb.gov.sg/cgi-bin/spydus.exe/FULL/EXPNOS/BIBENQ/24619186/195918293,80'),
('Computers for seniors for dummies', 'A first computer can be confusing and intimidating at any age. Luckily, \'Computers For Seniors For Dummies\' is here to help the over-55 crowd conquer the uncertainty and fear with clear-cut, easy-to-understand steps on how to get the most out of your new computer. Inside, you\'ll find step-by-step guidance on getting started, from turning the computer on and using the keyboard and mouse to finding your way around the new Windows 9 operating system. In no time, you\'ll confidently navigate your way around your new computer to email with family and friends, stay connected on social media, shop securely online, research topics of interest, find recipes and diet tips, and so much more. The computer has become a household and business mainstay and continues to change the way people communicate, work, shop, invest, and spend their free time. Whether you\'re looking to use a computer for bookkeeping, making travel pans, socializing, shopping, or just plain fun, this clear and friendly guide takes the intimidation out of computer basics and the ever-evolving technology that surrounds it.','http://catalogue.nlb.gov.sg/cgi-bin/spydus.exe/FULL/EXPNOS/BIBENQ/31152557/153926794,3'),
('The science of computers', 'The Science of Computers takes an overall look at information technology, exploring how computers operate and the amazing devices that are used in homes, schools, and businesses today. Students will be fascinated by the history of the development of information technology and digital devices from the early computers that filled entire buildings to the tiny silicon chips being produced today. This practical learning guide lays the groundwork for further exploration of computational thinking. Stretch Yourself features give practical activities to help readers explore and test key principles to help reinforce learning and are not linked to specific software or operating systems. ""True Story features give real-world anecdotes from the world of information technology. ComputerHero features look at the groundbreaking scientists that paved the way for digital technology today', 'http://catalogue.nlb.gov.sg/cgi-bin/spydus.exe/FULL/EXPNOS/BIBENQ/31152557/169275330,2'),
('Computer security', 'This text presents ideas that high technology, classical security practice, and common sense can help provide secure computer systems. It contains new information on the advances in computer equipment and the spread of technology.','http://catalogue.nlb.gov.sg/cgi-bin/spydus.exe/FULL/EXPNOS/BIBENQ/31152557/2468118,13'),
('The computer', 'The Computer traces the evolution of this vital machine from its earliest roots through its exciting application in code-breaking during the Second World War, and from its initial use in the workplace and home to its current status as a totally indispensable part of twenty-first century life. Along the way the author examines some colourful moments in the computer\'s development, from the key battle between Apple and IBM in the 1980s, to the use of computers in film and television such as the 1950s film The Forbidden Planet. The speed at which computer technology is progressing is staggering, and the final chapter looks forward to a time when computers will be on our wrists, in our cars - and possibly in our bodies',	'http://catalogue.nlb.gov.sg/cgi-bin/spydus.exe/FULL/EXPNOS/BIBENQ/31152557/59124479,6'),
('Self-driving cars', 'Self-driving cars are a Modern Engineering Marvel! In this engaging title, readers will explore the history of cars from early steam-powered wagons to toady\'s luxury sedans. The father of Self-Driving Cars, Sebastian Thrun, is featured, and a colorful infographic shows how a Google Car works. Readers will learn about advancements in computer technology that made cars more automated and how car companies are continuing to expand the capabilities of the self-driving car. A timeline, a glossary, and an index supplement historical and color photos. Aligned to Common Core Standards and correlated to state standards.',	'http://catalogue.nlb.gov.sg/cgi-bin/spydus.exe/FULL/EXPNOS/BIBENQ/31152557/222548884,20'),
('Human body!	The ultimate head-to-toe guide to the human body for kids.', 'Incredible computer-generated images reveal the amazing inside story of what goes on under our skin. All-new 3D illustrations offer a unique, strikingly realistic close-up of this fascinating, complex machine - what it looks like and how it works. Every image is supported with easy-to-understand explanations and a wealth of fascinating facts and figures. Knowledge Encyclopedia Human Body! allows you to take a closer look at the amazing world of your own human body and is perfect for children aged 9 and up.', 'http://catalogue.nlb.gov.sg/cgi-bin/spydus.exe/FULL/EXPNOS/BIBENQ/31152557/222558424,18'),
('Amazing applications and perfect programs', 'Amazing Applications and Perfect Programs helps explain operating systems, computer programs, sorting and storing files, databases, and the programs that allow users to have fun with words, pictures, and sounds. The computers that are used in schools, homes, and businesses around the world rely on programs. Learn about the amazing variety of programs available today and how they can be used for the most complicated finances or for simple word processing. Exercises teach key skills such as word processing, creating documents, and using databases. ""Stretch Yourself task boxes give practical activities for readers to try to help reinforce learning and are not linked to specific software or operating systems. True Story features give real-world anecdotes from the world of information technology. Computer Hero features look at the groundbreaking scientists that paved the way for digital technology today.', 'http://catalogue.nlb.gov.sg/cgi-bin/spydus.exe/FULL/EXPNOS/BIBENQ/545784/140852937,10'),
('Database of dreams : the lost quest to catalog humanity', 'Just a few years before the dawn of the digital age, Harvard psychologist Bert Kaplan set out to build the largest database of sociological information ever assembled. It was the mid-1950s, and social scientists were entranced by the human insights promised by Rorschach tests and other innovative scientific protocols. Kaplan, along with anthropologist A. I. Hallowell and a team of researchers, sought out a varied range of non-European subjects-among remote and non-literate peoples around the globe and elsewhere. Recording their dreams, stories, and innermost thoughts in a vast database, Kaplan envisioned future researchers accessing the data through the cutting-edge Readex machine. Almost immediately, however, technological developments and the obsolescence of the theoretical framework rendered the project irrelevant, and eventually it was forgotten. In a scrupulously researched and captivating new book, Rebecca Lemov recounts the story of Kaplan\'s quest and brings to light an informative and disturbing chapter in the prehistory of Big Data.', 'http://catalogue.nlb.gov.sg/cgi-bin/spydus.exe/FULL/EXPNOS/BIBENQ/547654/149903365,4'),
('Careers in database design', 'Explains the responsibilities of database designers and troubleshooters, describes the training required, and discusses possible career paths.' ,'http://catalogue.nlb.gov.sg/cgi-bin/spydus.exe/FULL/EXPNOS/BIBENQ/547654/5159602,14'),
('Beginning PHP 4 Databases', 'This volume is a tutorial, a resource and a reference for PHP programmers who now want to use databases in their applications. No knowledge of database management systems is assumed. After reading the book, developers will be fluent in database systems and how to take advantage of them in their PHP applications. They will also have gained extensive exposure to post-relational and XML-native databases, and be able to decide when to use which type of database system.', 'http://catalogue.nlb.gov.sg/cgi-bin/spydus.exe/FULL/EXPNOS/BIBENQ/547654/5062746,15'),
('Database : models, language, design', 'This textbook presents the topics that are traditionally included in a first undergraduate computer science course in database theory. Included are helpful examples, as well as some five hundred exercises.', 'http://catalogue.nlb.gov.sg/cgi-bin/spydus.exe/FULL/EXPNOS/BIBENQ/547654/2366381,21'),
('Banking systems simulation : theory, practice, and application of modeling shocks, losses, and contagion', 'Combining both academic and institutional knowledge and experience, Banking Systems Simulation: Theory, Practice, and Application of Modeling Shocks, Losses, and Contagion presents banking system risk modeling clearly within a theoretical framework. Written from the global financial perspective, the book explores single bank risk, common bank exposures, and contagion, and how these apply on a systemic level. Zedda approaches these simulation methods logically by providing the basic building blocks of modeling and simulation, and then delving further into the individual techniques that make up a systems model. In addition, the author provides clear and detailed explanations of the foundational research into the mathematical and legal concepts used to analyze banking risk problems, measures and data for representing the main banking risk sources, and the major problems researchers are likely to encounter. There are numerous software descriptions throughout, with references and tools to help readers gain a proper understanding of the presented techniques and possibly develop new applications and research. The book concludes with an appendix that features real-world datasets and models.', 'http://catalogue.nlb.gov.sg/cgi-bin/spydus.exe/FULL/EXPNOS/BIBENQ/547654/222560866,31'),
('Becoming a systems analyst', 'The world of IT is ever changing, with new operating systems, software packages, and hardware equipment introduced at a breakneck speed. Technical analysts provide the computer database support for organizations and their users. They implement upgrades, perform computing system maintenance and testing, develop IT solutions to improve quality, and design interfaces that help users access information in a timely, efficient manner. This title explores the technical analyst career path, an exciting position with a leading role in coordination and management of all IT design and development systems for an organization.', 'http://catalogue.nlb.gov.sg/cgi-bin/spydus.exe/FULL/EXPNOS/BIBENQ/547654/222557871,32'),
('Java all-in-one', 'Doug Lowe present all you need to know for getting started with Java. The text includes details on Web programming, creating GUI programs with JavaFX, file and database programming, working with arrays and collections and object oriented programming.', 'http://catalogue.nlb.gov.sg/cgi-bin/spydus.exe/FULL/EXPNOS/BIBENQ/547654/222556497,34'),
('The black widow ', 'Gabriel Allon, the art restorer, spy, and assassin, is poised to become the chief of Israel\'s secret intelligence service. But on the eve of his promotion, events conspire to lure him into the field for one final operation. ISIS has detonated a massive bomb in the Marais district of Paris, and a desperate French government wants Gabriel to eliminate the man responsible before he can strike again. They call him Saladin, a terrorist mastermind whose ambition is as grandiose as his nom de guerre, a man so elusive that even his nationality is not known. Shielded by sophisticated encryption software, his network communicates in total secrecy, leaving the West blind to his planning -- and leaving Gabriel no choice but to insert an agent into the most dangerous terror group the world has ever known. She is an extraordinary young doctor, as brave as she is beautiful. At Gabriel\'s behest, she will pose as an ISIS recruit in waiting, a ticking time bomb -- a black widow out for blood.', 'http://catalogue.nlb.gov.sg/cgi-bin/spydus.exe/FULL/EXPNOS/BIBENQ/547654/222550050,41'),
('Beginning Python : from novice to professional', 'Gain a fundamental understanding of Python\'s syntax and features with the third edition of Beginning Python, an up-to-date introduction and practical reference. Covering a wide array of Python-related programming topics, including addressing language internals, database integration, network programming, and web services, you\'ll be guided by sound development principles. Ten accompanying projects will ensure you can get your hands dirty in no time.Updated to reflect the latest in Python programming paradigms and several of the most crucial features found in latest Python 3. Advanced topics such as extending Python and packaging/distributing Python applications, are also covered.', 'http://catalogue.nlb.gov.sg/cgi-bin/spydus.exe/FULL/EXPNOS/BIBENQ/547654/219427595,45'),
('Build mobile apps with Ionic 2 and Firebase : hybrid mobile app development ', 'Learn to build hybrid mobile apps using Ionic and Firebase. You\'ll build a Hacker News client app, which can view top stories in Hacker News, view comments of a story, add stories to favorites, etc. This introductory guide covers the whole cycle of hybrid mobile apps development. It\'s organized around implementing different user stories. For each story, this book not only talks about how to implement it but also explains related Ionic and Firebase concepts in detail. Using Apache Cordova, developers can create a new type of mobile app--a hybrid mobile app. Hybrid mobile apps actually run in an internal browser inside a wrapper created by Apache Cordova. With hybrid mobile apps, developers can have one single code base for different platforms. Developers also can use their existing web development skills. The Ionic framework builds on top of Apache Cordova and provides out-of-box components which make developing hybrid mobile apps much easier. Ionic uses Angular as the JavaScript framework and has a nice default UI style with a similar look and feel to native apps. Firebase is a realtime database which can be accessed in web apps using JavaScript. With Build Mobile Apps with Ionic 2 and Firebase you\'ll discover that just need to develop front-end code, there\'s no need to manage any back-end code or servers', 'http://catalogue.nlb.gov.sg/cgi-bin/spydus.exe/FULL/EXPNOS/BIBENQ/547654/219422986,48');


create table keyword
(ID int not null AUTO_INCREMENT primary key,
 word varchar(32)); 
 
 insert into keyword (word) values
 ('computer'),
 ('technology'),
 ('digital'),
 ('analyze'),
 ('data'),
 ('IT'),
 ('database'),
 ('system'),
 ('information'), 
 ('programming'), 
 ('software'), 
 ('security');
 
 
 create table frequency
 (docID int not null, 
  keyID int not null, 
  value int not null,
  CONSTRAINT frequency_pk PRIMARY KEY (docID, id),
  CONSTRAINT frequency_fk1 FOREIGN KEY (docID) REFERENCES book(id),
  CONSTRAINT frequency_fk2 FOREIGN KEY (keyID) REFERENCES keyword(id)
  );


DELIMITER $$
CREATE FUNCTION count_words(abstract TEXT, word TEXT) RETURNS INTEGER
BEGIN

    DECLARE before_abstract TEXT; 
    DECLARE after_abstract TEXT; 
    DECLARE count INT;
    
    SET before_abstract = lcase(abstract);
    
	SET after_abstract = replace(before_abstract, lcase(word), '');
    
    SET count = (length(before_abstract) - length(after_abstract)) / length(word);
    
    RETURN count;
    
END$$
DELIMITER ;
drop function count_words;


DELIMITER $$
CREATE PROCEDURE sp_populate_frequency()
BEGIN

	
	DECLARE total_books_count INT;
	DECLARE total_keywords_count INT;
    
    DECLARE current_keyword_ID INT DEFAULT 1;
    DECLARE current_keyword varchar(32);
    DECLARE current_abstract TEXT;
    DECLARE current_frequency INT;
    
    # Books Upper Bound
    SELECT count(*) INTO total_books_count
    FROM book;
    
    # Words Upper Bound
    SELECT count(*) INTO total_keywords_count
    FROM keyword;
    
    
    WHILE total_books_count > 0 DO
    
			SELECT abstract INTO current_abstract
				FROM Book
                WHERE id = total_books_count;
		
			WHILE current_keyword_ID <= total_keywords_count DO
            
				SELECT word INTO current_keyword
					FROM Keyword
					WHERE Id = current_keyword_ID;
                
				SET current_frequency = count_words(current_abstract, current_keyword);
                
                INSERT INTO Frequency VALUES (total_books_count, current_keyword_ID, current_frequency);
                SET current_keyword_ID = current_keyword_ID + 1;
            END WHILE;
            
			SET total_books_count = total_books_count - 1;
			SET current_keyword_ID = 1;
        
    END WHILE;

END$$

DELIMITER ; 

drop procedure sp_populate_frequency;
TRUNCATE `Week13Lab`.`Frequency`;

call sp_populate_frequency();
SELECT * FROM frequency;


DELIMITER $$
CREATE FUNCTION calculate_length(book_ID INT, total_keywords_count INT) RETURNS DOUBLE
BEGIN

	DECLARE current_keyword_ID INT DEFAULT 1;
	DECLARE total_value DOUBLE DEFAULT 0;
	DECLARE final_value DOUBLE;

	WHILE current_keyword_ID <= total_keywords_count DO
    
		SET total_value = total_value + (SELECT POWER(value, 2) FROM Frequency
			WHERE docID = book_ID AND keyID = current_keyword_ID);
        
        SET current_keyword_ID = current_keyword_ID + 1;
    
    END WHILE;
    SET final_value = SQRT(total_value);
    
    RETURN final_value;
    
END$$
DELIMITER ;

drop function calculate_length;

call sp_get_similary(1, 2, @sim_val);
SELECT @sim_val;


DELIMITER $$
CREATE FUNCTION calculate_product(bookA_ID INT, bookB_ID INT, total_keywords_count INT) RETURNS INTEGER
BEGIN

	DECLARE current_keyword_ID INT DEFAULT 1;
	DECLARE value1 INT;
	DECLARE value2 INT;
	DECLARE total_value INT DEFAULT 0;

	WHILE current_keyword_ID <= total_keywords_count DO
    
		SET value1 = (SELECT value FROM Frequency
								WHERE docID = bookA_ID AND keyID = current_keyword_ID);
		
        SET value2 = (SELECT value FROM Frequency
								WHERE docID = bookB_ID AND keyID = current_keyword_ID);
    
		SET total_value = total_value + (value1 * value2);
		
        SET current_keyword_ID = current_keyword_ID + 1;
    
    END WHILE;
    
    RETURN total_value;
    
END$$
DELIMITER ;


DELIMITER $$
CREATE PROCEDURE sp_get_similarity(IN bookA_ID INT, IN bookB_ID INT, OUT sim_val DOUBLE)
BEGIN

    DECLARE total_keywords_count INT; 
    DECLARE bookA_length DOUBLE;
    DECLARE bookB_length DOUBLE;
    DECLARE product_value INT;
    
    # Words Upper Bound
    SELECT count(*) INTO total_keywords_count
    FROM keyword;
    
    SET bookA_length = calculate_length(bookA_ID, total_keywords_count);
    SET bookB_length = calculate_length(bookB_ID, total_keywords_count);
    SET product_value = calculate_product(bookA_ID, bookB_ID, total_keywords_count);
    
    SET sim_val = product_value / (bookA_length * bookB_length);

END$$
DELIMITER ;

DROP function calculate_product;
DROP function calculate_length;
DROP procedure sp_get_similary;

call sp_get_similarity(1, 2, @sim_val);
SELECT @sim_val;

####################################################################

insert into book (Title, Abstract, URL) values ('Query Q', 'data, database, information', 'https://elearn.smu.edu.sg/d2l/home');

delimiter $$
CREATE PROCEDURE sp_check_similarity
(IN bookID int, OUT similar_title varchar(150))
	BEGIN
	
	DECLARE count int default 1;
    DECLARE max_books int;
    DECLARE max_similarity double default 0.0;
    DECLARE extra double;
    
    SET max_books =
		(select count(*) from book);
	
    while (count <= max_books) do
		call sp_get_similarity(bookID, count, @sim_val);
        SET extra = (select @sim_val);
        
        if(extra > max_similarity and count <> bookID) then 
			SET max_similarity = extra;
            SET similar_title = (select title from book
								where id = count); 
		end if; 
        
		SET count = count + 1;
        
	end while;

END $$
delimiter ;

drop procedure sp_check_similarity;

call sp_check_similarity(32,@similarTitle);
select @similarTitle;
