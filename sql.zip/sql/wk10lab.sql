delimiter $$
create procedure getCustName 
	(IN custName varchar(45), out sa int, out fd int)
	BEGIN
    select count(*) into sa
    from account where cus_name = custName and acc_type = 'SA';
    
    select count(*) into fd
    from account where cus_name = custName and acc_type = 'FD' ;
    END$$
delimiter ;

call getCustName('Alex', @sa, @fd) ;
select @sa as CountSavings, @fd as CountFD;
    
drop procedure getCustName;

select count(*) as SA
    from account where acc_type = 'SA';