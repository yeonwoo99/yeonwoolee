#Qn1
SELECT BID, BNAME FROM BILL WHERE VoteDate < '2017-12-31';

#Qn2
SELECT SID, SNAME FROM STATE WHERE SNAME like '%or%';

#Qn3
SELECT CID, CNAME FROM congressperson WHERE StateRepresented in ('CA', 'FL', 'CO');

#Qn4
SELECT BID FROM BILLPROPOSAL GROUP BY bid having count(cid) =1;

#Qn5
CREATE TABLE Committee 
(cid int primary key,
startdate date not null,
enddate date not null);

CREATE TABLE committeemember
(
cid int NOT NULL,
mid int NOT NULL,
PRIMARY KEY (cid,mid),
CONSTRAINT FK_1 FOREIGN KEY (CID) REFERENCES CONGRESSPERSON (CID),
CONSTRAINT FK_2 FOREIGN KEY (MID) REFERENCES COMMITTEE(CID)
) ;

#Qn6
SELECT s.sid, s.sname FROM STATE s, congressperson cp
WHERE s.sid = cp.staterepresented group by s.sid having count(cp.staterepresented) >=1;

#Qn7
SELECT c.cid, c.cname, b.bid FROM Congressperson c
LEFT OUTER JOIN billproposal b ON c.cid = b.cid;

#Qn8
SELECT c.cid, c.cname, b.bid FROM Congressperson c
LEFT OUTER JOIN billproposal b ON c.cid = b.cid
WHERE b.bid is NULL;

#Qn9
SELECT BID, BNAME FROM bill b
WHERE bid in (SELECT bid from billvote where vote != 'Neutral') and (SELECT bp.bid FROM billproposal bp group by bp.bid having(bp.cid) >=1);

#Qn10
Select c.cid, c.cname from congressperson c, billvote bv
where c.cid = bv.cid and bv.vote ='Support';

#Qn11
Select b.bid, b.bname, count(distinct bv.vote) as NoOfVotes From Billvote bv, bill b
where b.bid = bv.bid and b.bid in (SELECT bid from Bill group by bid)
group by b.bid, b.bname;




