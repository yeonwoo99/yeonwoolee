delimiter $$
create trigger before_delete_account before delete on account
for each row
begin
	delete from transacion where acc_num = old.acc_num;
    insert into deleted_accounts values
		(old.acc_num, old.acc_type, old.cus_name, old.balance, current_timestamp());
end$$
delimiter ;