delimiter $$
CREATE TRIGGER after_transaction
	AFTER INSERT ON transaction FOR EACH ROW
    BEGIN
		declare l_type CHAR(1);
		set l_type = new.trans_type;
			if l_type = 'D' THEN
				update account set balance = balance + new.amount
                where acc_num = new.acc_num;
			elseif l_type = 'W' then
				update account set balance = balance - new.amount
                where acc_num = new.acc_num;
			end if;
	end $$
delimiter ;

insert into transaction(acc_num, amount, trans_type) values
('A9',200, 'D');
insert into transaction(acc_num, amount, trans_type) values
('A9',100, 'W'); 
                             
select * from account