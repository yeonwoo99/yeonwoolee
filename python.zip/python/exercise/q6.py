# declare constants. 
# Use uppercase alphabets separated by underscores.
ONE = 'I'
FOUR = 'IV'
FIVE = 'V'
NINE = 'IX'
TEN = 'X'
FORTY = 'XL'
FIFTY = 'L'
NINETY = 'XC'
HUNDRED = 'C'
FOUR_HUNDRED = 'CD'
FIVE_HUNDRED = 'D'
NINE_HUNDRED = 'CM'
THOUSAND = 'M'

# prompt for a number (< 5000)
num = int( input('Give a number :')) 

result = ''

# figure out the number of thousands (i.e. M)
count = num // 1000
num = num % 1000            # count how many hundreds left after removing thousands 
result +=  THOUSAND * count # adds the thousands literal into roman

count = num // 900
num = num % 900             
result +=  NINE_HUNDRED * count 

count = num // 500
num = num % 500             
result +=  FIVE_HUNDRED * count 

count = num // 400
num = num % 400             
result +=  FOUR_HUNDRED * count 

count = num // 100
num = num % 100             
result +=  HUNDRED * count 

count = num // 90
num = num % 90             
result +=  NINETY * count 

count = num // 50
num = num % 50             
result +=  FIFTY * count 

count = num // 40
num = num % 40             
result +=  FORTY * count

count = num // 10
num = num % 10             
result +=  TEN * count

count = num // 9
num = num % 9             
result +=  NINE * count

count = num // 5
num = num % 5             
result +=  FIVE * count

count = num // 4
num = num % 4             
result +=  FOUR * count

count = num  # eemainder        
result +=  ONE * count

print("Roman equivalent:" + result)