def to_binary(dec):
    if dec == 0:
        return "0"

    rem_string = ""  
    while(dec >= 1):    
        rem = dec % 2
        dec = dec // 2
        rem_string += str(rem)
  
    #reverses the string
    return rem_string[::-1]

print("The decimal number is 32 ") 
print("Binary equivalent of 32 is", to_binary(32))