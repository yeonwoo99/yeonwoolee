def retrieve_numbers_v2(value):
    result = '' 

    for i in range(len(value)):
        if value[i].isdigit():
            result += value[i]
        # we just met a non-space and we have yet to append a space to result
        elif result[-1:] != ' ':  # use slicing to avoid indexing error
            result += ' '
    
    return result[1:] 

def retrieve_numbers(value):
    result = ''
    for i in range(len(value)):
        if value[i].isdigit():
            # print(value[i])
            result += value[i]
            if not value[i + 1:i + 2].isdigit():
                result += ' '
    
    return result[:] # added so that this script will run. feel free to modify it

# the boolean variable is really not un-necessary for this case.
# see earlier 2 solutions
def retrieve_numbers_v3(value):
    result = ''
    is_digit = True
    for i in range(len(value)):
        if value[i].isdigit():
            result += value[i]
            is_digit = True   
        elif is_digit:
            result += ' '
            is_digit = False
 
    return result.strip() # added so that this script will run. feel free to modify it

# end of answer

print ('Test 1:')
print ('Expected:12 600 0900 100')
result = retrieve_numbers("12abc600$##0900AB 100X")
print ('Actual  :' + result)
print()

print ('Test 2:')
print ('Expected:34 5689 980')
result = retrieve_numbers("34.5689abc980") 
print ('Actual  :' + result)
print()

print('Test 3:')
print('Expected:[]')
result = retrieve_numbers("xyz") 
print('Actual  :[' + result + ']')
print()

print('Test 4:')
print('Expected:25')
result = retrieve_numbers("abc25xyz") 
print('Actual  :' + result)
print()

