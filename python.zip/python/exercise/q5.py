def print_decr_square(start, end):
    value = ''
    for i in range(start, end - 1, -1):
        value += str(i)

    # start - end will give the size of the square
    for i in range (start - end + 1):
        print ( value[i:] + value[0:i])

def print_decr_square_v2(start, end):
    difference = start - end + 1

    for i in range(difference):
        for j in range(difference):
            print(start - ((i + j) % difference), end='')
        print()


print_decr_square(8, 4)
print ('-' * 20)
print_decr_square_v2(8,4)