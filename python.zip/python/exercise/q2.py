def print_design(side, middle, n):
    output = side
    for i in range (n):
        output += middle    
    output += side
    return output

def print_a_row_of_boxes(side_length, num_boxes):
    side = print_design('+', '-', side_length-2)
    corner_row = ''
    for i in range(num_boxes):
        corner_row += side + ' '  
    
    middle = print_design('|', ' ', side_length-2)
    middle_row = ''
    for i in range(num_boxes):
        middle_row += middle + ' '

    print (corner_row)
    for i in range (side_length - 2):
        print (middle_row)
    print (corner_row)


print_a_row_of_boxes(5, 3)
