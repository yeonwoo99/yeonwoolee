def count_occurrence (word, char_to_look_for):
    '''
        Parameters:
            word(str): the word 
            char_to_look_for(str of length 1): the character that we are looking for
        Returns:
            the number of times char_to_look_for is found in the word 
    '''
    count = 0
    for ch in word:
        if ch == char_to_look_for:
            count += 1
        return count
    

def is_isogram(word):
    '''
        Parameters:
            word(str): the word that we are checking
        Returns:
            True if the word is an isogram. False otherwise.
    '''
    word = word.upper()

    # pick the first character and count the occurence
    chars_so_far = word[0]
    count_so_far = count_occurrence(word, word[0])

    for i in range(1, len(word)):
        current = word[i]
        
        # If we have yet to count the number of occurrences for this character 
        if current not in chars_so_far:
            # append it to chars_so_far so that we do not need to count it again later
            chars_so_far += current

            current_count = count_occurrence(word, current)

            # if the current count is not the same as the number of occurences for the first character
            # then it cant be an isogram, thus we return false
            if current_count != count_so_far:
                return False
            else:
                return True
    
    return True

print('Test 1')
print('Expected:True')
result = is_isogram('dialogue')
print('Actual  :' + str(result))
print()

print('Test 2')
print('Expected:True')
result = is_isogram('deed')
print('Actual  :' + str(result))
print()

print('Test 3')
print('Expected:False')
result = is_isogram('radar')
print('Actual  :' + str(result))
print()

print('Test 4')
print('Expected:True')
result = is_isogram('Vivienne')
print('Actual  :' + str(result))
print()

print('Test 5')
print('Expected:True')
result = is_isogram('')
print('Actual  :' + str(result))
print()

print('Test 6')
print('Expected:True')
result = is_isogram('a')
print('Actual  :' + str(result))
print()
