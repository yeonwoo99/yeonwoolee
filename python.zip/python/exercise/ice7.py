def is_good_password(password):
    pwd_len = len(password)

    if pwd_len < 6 or pwd_len > 20:
        return False

    has_lower = False
    has_upper = False
    has_digit = False
    for ch in password:
        if ch >= 'a' and ch <= 'z':
            has_lower = True
        elif ch >= 'A' and ch <= 'Z':
            has_upper = True
        elif ch >= '0' and ch <= '9':
            has_digit = True
        
        # if it has a uppercase, a lowercase and digit, the condition is fulfilled.
        # there is no need to check any further
        if has_lower and has_upper and has_digit:
            return True
    
    return False
