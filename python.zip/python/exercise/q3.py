sentence = input('Enter word>')

 # count variable stores how many times we are seeing the character in prev. 
 # it is initialzed to 1 because the char at position 0 is the first occurrence
prev = sentence[0]
count = 1

output = ''
for i in range(1, len(sentence)):
    current = sentence[i]
    if current == prev:
        count += 1
    else: # a new character has appeared
        output += prev + str(count)
        count = 1
        prev = current

# print out the last character and its count
output += sentence[i] + str(count)
print (output)