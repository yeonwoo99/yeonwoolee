def is_pangram(password):

    # u can choose to convert everything to upper or lowercase. I picked lower here
    password = password.lower()
    alphabets = 'abcdefghijklmnopqrstuvwxyz'
    # alternatively, you can use string.ascii_lowercase (constant defined by python)
    # ie. the below statement:
    # for ch in string.ascii_lowercase:
    for ch in alphabets:    #what we are doing is checking if all alphabets are present (one by one)
        if ch not in password:
            return False
    return True
            
def is_pangram_v2(password):
    password = password.upper()  #we chose to convert password into uppercase here
    alphabets = ''
    for ch in password:
        # over here, we need to exclude non-alphabets 
        # alternatively, u can use string.ascii_uppercase
        # i.e. the below statement:
        # if ch not in alphabets and ch in string.ascii_uppercase:
        if ch not in alphabets and (ch >= 'A' and ch <= 'Z'):
            alphabets += ch

    return len(alphabets) == 26


print(is_pangram('The quick brown fox jumps over the lazy dog.'))
print(is_pangram_v2('The quick brown fox jumps over the lazy dog.'))