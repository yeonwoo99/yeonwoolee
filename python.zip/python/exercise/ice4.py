def print_board(): #this function shows the board with positions in the beginning of the game
    print("\nPlayers, Choose positions 0 to 8:")
    print("=======")
    print("|0|1|2|")
    print("|3|4|5|")
    print("|6|7|8|")
    print("=======")
  
  
def update_board(board):  #this function displays the board with players' moves
    print("=======")  
    for i in range(len(board)):
        print("|", end="")
        print(board[i],end="")
        if i % 3 == 2:  #prints the last | in every row
            print("|")  
    print("=======")


def next_player(current_player):  #this function facilitates choosing alternate players to play
    if current_player == "X":
        return "O"
    # otherwise
    return "X"
    
def is_valid_pos(pos, placed): #returns True if player chooses a valid position, else returns False
    return pos >= 0 and pos < 9 and placed[pos] == " "


def update_player_move(pos, current_player, board): #the current_player's move is updated on the board
    board[pos] = current_player
  
def has_won(player, board):  #player can be X or O, board has all moves
    return board[0] == player and board[1] == player and board[2] == player or \
      board[3] == player and board[4] == player and board[5] == player or \
      board[6] == player and board[7] == player and board[8] == player or \
      board[0] == player and board[3] == player and board[6] == player or \
      board[1] == player and board[4] == player and board[7] == player or \
      board[2] == player and board[5] == player and board[8] == player or \
      board[0] == player and board[4] == player and board[8] == player or \
      board[2] == player and board[4] == player and board[6] == player
   
def check_winner(board):
    if has_won("X", board):
        return "X"
    elif has_won("O", board):
        return "O"
    return None

def is_full(board):  #returns True if all positions on the board is filled, else False
    return board.count(" ") == 0

#set variables in the beginning of the game  
current_player = "X"
board = [" "," "," "," "," "," "," "," "," "]
continue_game = True

print_board()

while continue_game:
    print("\nPlayer", current_player ,end="")
    pos = int(input(", choose position :"))
    
    while not is_valid_pos(pos, board):
        pos = int(input("Player "+ current_player + ", choose position :"))
    
    update_player_move(pos, current_player, board)
    update_board(board)
    
    winner = check_winner(board)
    if winner  != None or is_full(board):
        continue_game = False

        if winner == "X":
            print("Player X wins!")
        elif winner == "O":
            print("Player O wins!")
        else:
            print("This game is a draw!")
        

    current_player = next_player(current_player)

