def print_menu():
    print("Menu:")
    print("1. Choose a particular table to practice")
    print("2. Practice with a random table")
    print("3. Quit")
    choice = int(input("Your choice ?"))
    return choice

def show_quiz(num):
    score = 0
    for cnt in range(10): #10 questions
        print(cnt+1, '*', num, '= ', end = '')
        ans = input()
    
        if int(ans) == (cnt+1) * num:
            print("Correct!")
            score += 1
        else:
            print("Wrong!")
  
    print("Your score:",score,"/ 10")
    print()

def gen_random():
    import random
    return random.randrange(2,11)  
  
option = print_menu()
while (option != 3):  #3 is quit option
    if option == 1:
        quiz_num = int(input("The multiplication table you wish to practice ?"))
        show_quiz(quiz_num)
    elif option == 2:
        quiz_num = gen_random()
        print("You will be quizzed on multiplication table:", quiz_num)
        show_quiz(quiz_num)
    else:
        print("Invalid choice")
        print()
    
    option = print_menu()
  
print("Bye!")



  
  