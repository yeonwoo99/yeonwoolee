def merge(list1, list2):
    len1 = len(list1)
    len2 = len(list2)
    output = []
    
    pos1 = 0
    pos2 = 0
    
    while pos1 < len1 and pos2 < len2: #continue the loop until there are tuples in both lists at the positions
        one = list1[pos1]     #read the first tuple from both lists
        two = list2[pos2]
        
        if one[1] <= two[1]:   #compare the ages of first tuple from both lists
            output.append(one)  #add the tuple with lower age
            pos1 += 1
        else:
            output.append(two)
            pos2 += 1
        
    #add the remaining names from the lists 
    output += list1[pos1:]    
    output += list2[pos2:]
    
    return output
    
  
list1 = [("John", 12), ("Kate", 15), ("Henry", 35)]
list2 = [("Mike", 18), ("Scott", 20), ("Joseph", 48), ("Larry", 54)] 

print(merge(list1, list2))
#[("John", 12), ("Kate", 15), ("Mike", 18), ("Scott", 20), ("Henry", 35), ("Joseph", 48), ("Larry", 54)]
 

list1 = [("Mike", 12), ("Scott", 20), ("Joseph", 28)]
list2 = [("John", 12), ("Kate", 15), ("Henry", 35)]
print(merge(list1, list2)) 
#[("Mike",12),("John",12),("Kate",15),("Scott",20),("Joseph",28),("Henry",35)]

list1 = []
list2 = [("John", 12), ("Kate", 15), ("Henry", 35)]
print(merge(list1, list2)) 
#[("John", 12), ("Kate", 15), ("Henry", 35)]

list1 = []
list2 = []
print(merge(list1, list2)) 
#[]
