import random

continue_game = 'Y'

while continue_game == 'Y':
    number = random.randrange(1,101)
    #print(number) 

    totalGuesses = 0;   

    guess = 0  # initialize to a value outside the range

    while guess != number:   
        guess = input("Enter your guess(1 to 100) :") 
        totalGuesses += 1

        while not (guess.isdigit()):
            print("Wrong input.")
            guess = input("Enter your guess(1 to 100) :")  
            totalGuesses += 1
    
        guess = int(guess)

        if guess < number:
            print("Low! Try again")
        elif guess > number:
            print("High! Try again") 
      
    
    print("Congrats!\nYou guessed in", totalGuesses, "attempts")

    continue_game = input(("\nDo you want to play again(Y for yes) ?") ).upper()

print("Bye!")
