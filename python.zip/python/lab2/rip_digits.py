# 5(b)

def rip_digit(number):
    if number < 10:
        print (number)
    else:
        rip_digit(number // 10)
        print (number % 10)
number = int(input ('Enter a positive integer:'))
rip_digit(number)

