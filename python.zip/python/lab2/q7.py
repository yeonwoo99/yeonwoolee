def read_from_file(filename):
    result = []
    with open(filename) as file:
        for line in file:
            result.append(line.strip())
    
    return result

def find_words(sentence, english_words):
    n = len(sentence)
 
    if n == 0:
        return []

    result = []
    is_word_found = False
    for  i in range(1, n):
        if sentence[0:i] in english_words:
            if i == n - 1:
                return [sentence[0:i]]

            return_value =  find_words (sentence[i:], english_words)
            if return_value != None:
                result.append(sentence[0:i])
                result += return_value
                return result

    return None

def decompose_into_words(sentence, filename):
    english_words = read_from_file(filename)

    result = find_words(sentence, english_words)
    if result == None:
        return ''
    return ' '.join(result)


