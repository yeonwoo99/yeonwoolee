def get_max_sum_sublist(numbers, k):
    if len(numbers) < k:
        return []

    sublist = numbers[0:k]
    largest = sum(sublist)
    for i in range(1, len(numbers)-k):
        current = numbers[i:i+k]
        current_sum = sum (current)
        if current_sum > largest:
            largest = current_sum
            sublist = current

    return sublist


        
