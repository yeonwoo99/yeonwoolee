from q4 import is_all__list_sorted

print ('TC 1')

result = is_all__list_sorted([[3, 3, 9, 12], [11, 7, 3], [1,2]])
print ('Expected:True')
print ('Actual  :' + str(result))
print ()
print ("Expected data type:<class 'bool'>")
print ('Actual data type  :' + str(type(result)))
print ()

result = is_all__list_sorted([[3, 9, 12], [11, 1, 3], [1,2]])
print ('TC 2')
print ('Expected:False')
print ('Actual  :' + str(result))
print ()

result = is_all__list_sorted([[], []])
print ('TC 2')
print ('Expected:False')
print ('Actual  :' + str(result))
print ()


