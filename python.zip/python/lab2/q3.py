def calculate_total(values):
    total = 0
    for a_value in values:
        total += int(a_value)
    return int(total / len(values))

def get_average_per_active_day(file_name):
    result = []
    with open(file_name) as file:
        for line in file:
            line = line.strip()
            
            import re
            values = re.split(':|\\|', line)

            average = 0
            if values[1] != '':
                average = calculate_total(values[1:])
            result.append( (values[0], average) )
    return result
