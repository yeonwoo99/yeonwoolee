from q6 import get_longest_sorted_sequence

print ('TC 1')
print ('Expected:3')
print ('Actual  :' + str(get_longest_sorted_sequence(['a', 'is', 'ape', 'in'])))
print ()
print ("Expected data type:<class 'int'>")
print ('Actual data type  :' + str(type(get_longest_sorted_sequence(['a', 'is', 'ape', 'in']))))
print ()


print ('TC 2')
print ('Expected:5')
print ('Actual  :' + str(get_longest_sorted_sequence(['apple', 'in', 'has', 'wed', 'code', 'rocks', 'bee'])))
print ()

print ('TC 3')
print ('Expected:1')
print ('Actual  :' + str(get_longest_sorted_sequence(['apple'])))
print ()

print ('TC 4')
print ('Expected:0')
print ('Actual  :' + str(get_longest_sorted_sequence([])))
print ()
