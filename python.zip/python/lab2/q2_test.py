from q2 import get_max_sum_sublist

print ('TC 1')
print ('Expected:[3, 9, 8, 13]')
result = get_max_sum_sublist ([11, 3, 9, 8, 13, 0, 12], 4)
print ('Actual  :' + str(result))
print ()
print ("Expected data type:<class 'list'>")
print ('Actual data type  :' + str(type(result)))
print ()

print ('TC 2')
print ('Expected:[9, 8, 7]')
result = get_max_sum_sublist ([11, 3, 9, 8, 7, 2], 3)
print ('Actual  :' + str(result))
print ()

print ('TC 3')
print ('Expected:[]')
result = get_max_sum_sublist ([11, 3], 3)
print ('Actual  :' + str(result))
print ()
