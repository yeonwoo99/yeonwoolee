from q1 import get_largest_sum_list


print ('TC 1')
result = get_largest_sum_list ([ [1,2,3], [5,8,1,3], [45] ])
print ('Expected:[45]')
print ('Actual  :' + str(result))
print ()
print ("Expected data type:<class 'list'>")
print ('Actual data type  :' + str(type(result)))
print ()


print ('TC 2')
result = get_largest_sum_list ([ [1,2,3], [3,2,1], [],[] ])
print ('Expected:[3, 2, 1]')
print ('Actual  :' + str(result))
print ()


print ('TC 3')
result = get_largest_sum_list ([ [], [] ])
print ('Expected:None')
print ('Actual  :' + str(result))
print ()


print ('TC 4')
result = get_largest_sum_list ([])
print ('Expected:None')
print ('Actual  :' + str(result))
print ()
