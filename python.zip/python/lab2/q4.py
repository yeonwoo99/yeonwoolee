def is_list_sorted(number_list):
    if len(number_list) <= 2:
        return True

    is_increasing = number_list[0] < number_list[-1]
    previous = number_list[0]
    for i in range(len(number_list)):
        current = number_list[i]
        if is_increasing:
            if current < previous:
                return False
        else:
            if current > previous:
                return False
        previous = current

    return True

def clean_empty_values(numbers):
    result = []

    for a_list in numbers:
        if a_list != []:
            result.append(a_list)
    return result

def is_all__list_sorted(numbers):
    cleaned = clean_empty_values(numbers)

    if cleaned == []:
        return False
    
    for a_list in cleaned:
        if not is_list_sorted(a_list):
            return False

    return True



