# write your answer here


def factorial(n):
    # 1! = 1, 0! = 1
    if n == 1 or n == 0:
        return 1
    else:
        return factorial(n - 1) * n




