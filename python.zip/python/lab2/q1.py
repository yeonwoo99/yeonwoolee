def get_total(values):
    total = 0
    for a_value in values:
        total += a_value
    return total

def remove_empty(number_list):
    result = []
    for a_list in number_list:
        if a_list != []:
            result.append(a_list)
    return result

def get_largest_sum_list(numbers):
    # remove all the empty list values
    numbers = remove_empty(numbers)
    
    if len(numbers) < 1:
        return None

    max_list = numbers[0]

    # instead of writing get_total function, you can use the 
    # inbuilt function called sum
    max_total = get_total(numbers[0])

    for i in range(len(numbers)):
        current_total = get_total(numbers[i])
        if max_total <= current_total:
                max_total = current_total
                max_list = numbers[i]


    
    return max_list
