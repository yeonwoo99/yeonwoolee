def get_longest_sorted_sequence(words):
    n = len(words)
    if n  < 1:
        return n

    max = 1
    count = 1
    previous = len(words[0])
    for i in range(1, n):
        current = len(words[i])
        if current >= previous:
            count += 1
        else:
            if count > max:
                max = count
            count = 1
        previous = current

    return max
