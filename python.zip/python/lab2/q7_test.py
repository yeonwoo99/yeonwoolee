from q7 import decompose_into_words

print ('TC 1')
print ('Expected:i love programming challenges of all kindsd')
print ('Actual  :' + decompose_into_words('iloveprogrammingchallengesofallkinds', 'q7-data.txt'))
