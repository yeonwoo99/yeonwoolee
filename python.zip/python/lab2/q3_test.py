from q3 import get_average_per_active_day

def check_data_type(result):
    if not isinstance(result, list):
        return False

    for a_value in result:
        if not isinstance(a_value, tuple):
            return False
    
    return True

print ('TC 1')
print ("Expected:[('Ah Beng', 8830), ('Ah Seng', 4593), ('Ah Lian', 5784), ('Ah Tiong', 0)]")
result = get_average_per_active_day ('q3-data.txt')
print ('Actual  :' + str(result))
print ()

print ('TC 2: checking data type match')
print ('Expected:True')
result = check_data_type(get_average_per_active_day ('q3-data.txt'))
print ('Actual  :' + str(result))
