# start of answer

def print_pattern(word, separator):

    output = ''
    for ch in word:
        output = ch + separator
    
    return output[1:]
    # return 0 # added so that this script will run. feel free to modify it



# end of answer
print()
print("Test 1")
print("expected:a-p-p-l-e")
result = print_pattern("apple", '-')
print("actual  :" + result)

print()
print("Test 2")
print("expected:H#I")
result = print_pattern("HI", '#')
print("actual  :" + result)

print()
print("Test 3")
print("expected:H")
result = print_pattern("H", '*')
print("actual  :" + result)

print()
print("Test 4")
print("expected:[]")
result = print_pattern("", '*')
print("actual  :[" + result + "]")

