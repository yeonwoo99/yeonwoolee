# start of answer

def print_triangle(value , ch):
    step = 1  # will go 1, 2, 3, 4 ...
    count = 1 

    toPrint = "";
    for i in range (len (value)):
        if i == count:
            print(toPrint)
            toPrint = ""
            step += 1
            count += step
        
        toPrint = toPrint + value[i]

    toPrint += ch * (count - len(value))
    print(toPrint)
    # return 0 # added so that this script will run. feel free to modify it



# end of answer

print("Test 1")
print("Expected:")
print("a")
print("bc")
print("def")
print("ghij")
print("Actual:")
print_triangle("abcdefghij", '#')

print()
print("------------")
print()

print("Test 2")
print("Expected:")
print("a")
print("b@")
print("Actual:")
print_triangle("ab", '@')

print()
print("------------")
print()

print("Test 3")
print("Expected:")
print("a")
print("bc")
print("def")
print("ghij")
print("k####")
print("Actual:")
print_triangle("abcdefghijk", '#')