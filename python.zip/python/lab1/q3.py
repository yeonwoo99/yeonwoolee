# start of answer

def  get_smallest_pair(number):
    if number < 10:
        return -1
        
    strNumber = str(number)

    smallest = int(strNumber[0]) * 10 + int(strNumber[1])

    for i in range(1, len(strNumber) - 1):
        first = int(strNumber[i])
        second = int(strNumber[i+1])

        pair = first * 10 + second
        if pair < smallest:
            smallest = pair

        return smallest
    # return 0 # added so that this script will run. feel free to modify it



# end of answer

print('Test 1: Check if int is returned')
print("Expected:True")
result = get_smallest_pair(2345)
print("Actual  :" + str(isinstance(result, int)))
print()

print('Test 2')
print("Expected:23")
result = get_smallest_pair(2345)
print("Actual  :" + str(result))
print()

print('Test 3')
print("Expected:2")
result =  get_smallest_pair(10245)
print("Actual  :" + str(result))
print()

print('Test 4')
print("Expected:-1")
result = get_smallest_pair(1)
print("Actual  :" + str(result))
print()

